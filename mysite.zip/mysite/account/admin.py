from django.contrib import admin
from . import models

admin.site.register(models.Reg_mesg)
admin.site.register(models.Employee)
admin.site.register(models.project)
admin.site.register(models.dailycheck)
admin.site.register(models.leave)
admin.site.register(models.business)
admin.site.register(models.extra)
admin.site.register(models.user_token)
