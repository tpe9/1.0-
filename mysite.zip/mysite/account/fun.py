from datetime import datetime
#import models
from hashlib import md5
import requests
import json

import base64

def encrypt_md5(s):
    # 创建md5对象
    new_md5 = md5()
    print('0')
    # 这里必须用encode()函数对字符串进行编码，不然会报 TypeError: Unicode-objects must be encoded before hashing
    new_md5.update(s.encode(encoding='utf-8'))
    print(new_md5.hexdigest())
    # 加密
    return new_md5.hexdigest()

def time_diff_now(d):
    if d==null:
        return 10000
    now = datetime.now()
    d1 = datetime.strptime(str(d), '%Y-%m-%d %H:%M:%S.%f')
    d2 = datetime.strptime(str(now), '%Y-%m-%d %H:%M:%S.%f')
    delta=d2-d1
    return delta.days*24*60*60+delta.seconds

def get_token():
    url='https://aip.baidubce.com/oauth/2.0/token'

    data={"grant_type":"client_credentials", "client_id":"GvHXiXf1VRTSheKox1a1jy7E", "client_secret":"vjfRfVragvhNRNFw206zwdF6tlEq6BqH"}

    headers={"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36"}

    html = requests.post(url, headers = headers,  data=data)
    if (html.content):
        data=json.loads(html.text)
    return(data['access_token'])


def base64encode(path):
    with open(path, 'rb') as f:
        base64_data = base64.b64encode(f.read())
        s = base64_data.decode()
        return s



def face_det(pic1,pic2):
    url='https://aip.baidubce.com/oauth/2.0/token'

    data={"grant_type":"client_credentials", "client_id":"GvHXiXf1VRTSheKox1a1jy7E", "client_secret":"vjfRfVragvhNRNFw206zwdF6tlEq6BqH"}

    headers={"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36"}

    html = requests.post(url, headers = headers,  data=data)
    if (html.content):
        data=json.loads(html.text)
    access_token=(data['access_token'])
    url='https://aip.baidubce.com/rest/2.0/face/v3/match'
    headers={"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36"}
    params = json.dumps(
        [{"image": base64encode(pic1), "image_type": "BASE64", "face_type": "LIVE", "quality_control": "LOW"},
        {"image": pic2, "image_type": "BASE64", "face_type": "IDCARD", "quality_control": "LOW"}])
    request_url = url + "?access_token=" + access_token
    respose=requests.post(request_url,data=params,headers=headers)
    data=json.loads(respose.text)
    if(data['result']['score']):
        if (data['result']['score'])>80:
            return True
    return False

encrypt_md5('LX2019-07-1023:22:13.994066')